# Flowboard

Dashboard **order-flow in tempo reale** per futures crypto (default: BTCUSDT perpetual su Binance).
Condensa sei misure di microstruttura in un unico verdetto — *chi sta spingendo il prezzo adesso* — e le mostra
una per una, così il verdetto resta verificabile.

Zero dipendenze, zero build, nessuna chiave API: HTML + ES modules + canvas.

![anteprima](docs/preview.png)

## Avvio

```bash
git clone <questo-repo> && cd flowboard
npm start            # oppure: python3 -m http.server 8080
# apri http://localhost:8080
```

| Parametro URL | Effetto |
|---|---|
| `?demo` | dati sintetici, funziona offline |
| `?tf=5` | timeframe in minuti (qualsiasi N: si aggrega da candele 1m) |
| `?symbol=ETHUSDT` | altro perpetual USDⓈ-M (crypto, oro, indici, azioni: vedi sotto) |
| `?session=us` | ancora il VWAP all'apertura cash USA (09:30 New York, con ora legale); `utc` (default) oppure `HH:MM` UTC |
| `?lot=250000` | soglia "lotto grande" in USD nozionali |

Deploy: fai push su `main` con **Settings → Pages → Source: GitHub Actions** e il workflow in
`.github/workflows/pages.yml` pubblica il sito dopo aver eseguito i test.

## Come si legge il verdetto

Il numero **compratori/venditori** non è un conteggio di ordini: è `50 + 50 × punteggio`, dove il punteggio è una
media pesata di sei segnali normalizzati in [-1, +1]. Un 59/41 corrisponde a un punteggio di circa +0,18.

| Segnale | Cosa misura | Peso |
|---|---|---|
| **Flusso taker** | (acquisti a mercato − vendite a mercato) / volume, miscelato su 1/5/15 min (25/50/25 %) | 30 % |
| **Prezzo vs VWAP** | distanza dal VWAP di sessione (ancorato a 00:00 UTC) in deviazioni standard pesate per volume | 20 % |
| **Delta cumulato 30m** | volume netto aggressivo; segnala divergenze (prezzo su con delta negativo = *rialzo debole*) | 15 % |
| **Order book** | sbilanciamento bid/ask sui primi 20 livelli, pesato per distanza dal mid (decadimento esponenziale, 8 bps) | 15 % |
| **Lotti grandi** | delta dei soli ordini singoli ≥ soglia (default 150.000 $ nozionali), scalato per la quantità osservata | 10 % |
| **Open interest** | variazione OI vs variazione prezzo su 5 min: nuovi long / nuovi short pesano più di short covering / liquidazioni | 10 % |

Dettagli di robustezza:

- **Smoothing EMA** sul punteggio a ogni tick (250 ms) e **verdetto con isteresi** (entra a ±0,15, esce a ±0,05): niente flicker.
- Le componenti mancanti (es. OI nei primi 5 minuti) escono dalla media e i pesi si **rinormalizzano**.
- Lo sbilanciamento del book è la misura più facile da manipolare (spoofing): per questo pesa solo il 15 %.
- Funding, spread, volatilità realizzata, liquidazioni a 5 min e distanza dal VWAP sono mostrati ma **non** entrano nel punteggio.

Tutto è tarabile in `src/config.js`.

## Altri asset: cosa funziona e cosa no

L'analisi si basa su dati che esistono solo dove c'è un feed di **singoli scambi con il lato aggressore**, il book e l'open interest.
Oggi Binance Futures li fornisce anche per i perpetual TradFi (oro `XAUUSDT`, argento `XAGUSDT`, petrolio, indici/ETF e azioni singole):

```
?symbol=XAUUSDT
?symbol=TSLAUSDT&session=us
```

Verifica che il simbolo esista nell'elenco Futures di Binance prima di usarlo; se non c'è, l'app mostra "Simbolo non trovato".

Attenzione a cosa stai guardando:

- Il perpetual **non è il mercato cash**: segue il sottostante tramite un indice, ma il flusso che vedi è quello dei trader del perpetual.
- Trada **24/7**, anche quando il sottostante è chiuso (notte, weekend): in quelle ore il flusso è sottile e spesso guidato dal solo perpetual.
- Il VWAP di sessione ha senso solo se ancorato a un'apertura reale: per indici e azioni usa `?session=us`.
- Gli **indici cash e le azioni "vere"** (S&P 500, Nasdaq, un CFD su broker) non hanno un feed gratuito con lato aggressore e book: per quelli servono dati a pagamento (trade + quote, per classificare gli scambi) e un nuovo provider in `src/feed.js`.

## Struttura

```
index.html          markup
src/config.js       parametri e pesi
src/session.js      ancoraggio del VWAP (UTC, apertura USA con ora legale, orario custom)
src/metrics.js      funzioni pure (VWAP, flusso, CVD, OBI, OI, composito) — testate
src/engine.js       stato di mercato + punteggio, indipendente da rete e DOM
src/feed.js         WebSocket Binance con riconnessione/watchdog + generatore demo
src/chart.js        candele, VWAP ±1σ, pannello delta (canvas)
src/main.js         collegamento UI
tests/              node:test
```

```bash
npm test
```

## Limiti noti (leggili)

- **Non prevede il prezzo.** Descrive l'aggressività recente; i pesi sono ragionevoli ma **non ottimizzati su dati storici**.
  Se vuoi usarlo operativamente, fai backtest e walk-forward prima.
- Usa solo **Binance**. L'order flow di un singolo exchange non è il mercato intero.
- Binance blocca alcuni paesi (HTTP 451): cambia `rest`/`ws` in `config.js` o usa un proxy.
- L'OI arriva da polling ogni 10 s: è un segnale lento, non tick-by-tick.
- Nessuna persistenza: ricaricando la pagina si riparte dalle ultime ~25 ore di candele 1m.

## Licenza

MIT. Non è consulenza finanziaria. I futures a leva possono azzerare il capitale.
