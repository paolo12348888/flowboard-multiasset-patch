import test from 'node:test';
import assert from 'node:assert/strict';
import { Engine } from '../src/engine.js';
import { CONFIG } from '../src/config.js';

const now = Date.UTC(2026, 10, 1, 12, 0, 30);
const minute = Math.floor(now / 60_000) * 60_000;

function seeded(buyBias) {
  const e = new Engine(CONFIG);
  const ks = Array.from({ length: 200 }, (_, i) => {
    const t = minute - (199 - i) * 60_000, p = 100_000 + (i % 2);
    return [t, p, p + 5, p - 5, p + 1, 10, 0, 0, 0, 5];
  });
  e.setHistory(ks);
  for (let i = 0; i < 300; i++) {
    const buy = i % 10 < buyBias * 10;
    e.onAggTrade({ p: 100_000, q: 0.5, T: now - 200_000 + i * 600, m: !buy });
  }
  const mk = (n) => Array.from({ length: 20 }, (_, i) => [String(100_000 + n * (i + 1) * 0.5), String(n > 0 ? 1 : 3)]);
  e.onDepth({ b: mk(-1), a: mk(1) });
  return e;
}

test('flusso dominato dagli acquisti => punteggio positivo e verdetto buy', () => {
  const e = seeded(0.9);
  let s; for (let i = 0; i < 80; i++) s = e.tick(10, now);
  assert.ok(s.score > 0.15, `score=${s.score}`);
  assert.equal(s.regime, 'buy');
  assert.ok(s.buyersPct > 55);
});

test('flusso dominato dalle vendite => punteggio negativo', () => {
  const e = seeded(0.1);
  let s; for (let i = 0; i < 80; i++) s = e.tick(10, now);
  assert.ok(s.score < 0, `score=${s.score}`);
});

test('senza dati ritorna null; OI assente non rompe il punteggio', () => {
  assert.equal(new Engine(CONFIG).tick(10, now), null);
  const s = seeded(0.5).snapshot(10, now);
  assert.equal(s.parts.oi, null);
  assert.ok(Number.isFinite(s.score));
});

test('aggTrade con m=true è vendita aggressiva; lotto grande in USD nozionali', () => {
  const e = new Engine({ ...CONFIG, largeLotUsd: 100 });
  e.onAggTrade({ p: 1, q: 500, T: now, m: true });   // $500 -> grande, venditore
  e.onAggTrade({ p: 1, q: 50, T: now, m: false });   // $50  -> piccolo, compratore
  const b = e.bins[0];
  assert.equal(b.sell, 500); assert.equal(b.lsell, 500); assert.equal(b.buy, 50); assert.equal(b.lbuy, 0);
});

test('onKline aggiorna la candela corrente e ne apre una nuova', () => {
  const e = seeded(0.5);
  const n = e.c1m.length;
  e.onKline({ t: minute, o: 1, h: 2, l: 0.5, c: 1.5, v: 3, V: 1 });
  assert.equal(e.c1m.length, n);
  e.onKline({ t: minute + 60_000, o: 1, h: 2, l: 0.5, c: 1.5, v: 3, V: 1 });
  assert.equal(e.c1m.length, n + 1);
});

test('liquidazioni: SELL = long liquidato', () => {
  const e = seeded(0.5);
  const T = Date.now();
  e.onForce({ o: { T, S: 'SELL', ap: 100, q: 2 } });
  e.onForce({ o: { T, S: 'BUY', ap: 100, q: 1 } });
  const s = e.snapshot(10, T);
  assert.equal(s.liq.long, 200); assert.equal(s.liq.short, 100);
});
