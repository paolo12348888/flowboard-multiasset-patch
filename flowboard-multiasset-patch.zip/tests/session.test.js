import test from 'node:test';
import assert from 'node:assert/strict';
import { makeSessionId } from '../src/session.js';
import * as M from '../src/metrics.js';

const utc = (iso) => Date.parse(iso);

test('utc: cambia a mezzanotte', () => {
  const id = makeSessionId('utc');
  assert.notEqual(id(utc('2026-11-01T23:59:00Z')), id(utc('2026-11-02T00:00:00Z')));
  assert.equal(id(utc('2026-11-01T00:00:00Z')), id(utc('2026-11-01T23:59:00Z')));
});

test('us: apertura 09:30 NY = 13:30 UTC con ora legale (ottobre)', () => {
  const id = makeSessionId('us');
  assert.notEqual(id(utc('2026-10-30T13:29:00Z')), id(utc('2026-10-30T13:30:00Z')));
  assert.equal(id(utc('2026-10-30T13:30:00Z')), id(utc('2026-10-30T20:00:00Z')));
});

test('us: apertura 09:30 NY = 14:30 UTC con ora solare (novembre)', () => {
  const id = makeSessionId('us');
  assert.notEqual(id(utc('2026-11-02T14:29:00Z')), id(utc('2026-11-02T14:30:00Z')));
  assert.equal(id(utc('2026-11-02T13:45:00Z')), id(utc('2026-11-02T14:29:00Z'))); // 13:45Z è ancora la sessione precedente
});

test("us: il giorno del cambio d'ora (1 nov 2026) non produce due sessioni nella stessa mattina", () => {
  const id = makeSessionId('us');
  // dopo il cambio, 14:30Z è l'apertura; 13:30Z appartiene ancora alla sessione di ieri
  assert.equal(id(utc('2026-11-01T13:30:00Z')), id(utc('2026-11-01T14:29:00Z')));
  assert.notEqual(id(utc('2026-11-01T14:29:00Z')), id(utc('2026-11-01T14:30:00Z')));
});

test('HH:MM personalizzato in UTC', () => {
  const id = makeSessionId('07:00');
  assert.notEqual(id(utc('2026-11-02T06:59:00Z')), id(utc('2026-11-02T07:00:00Z')));
});

test('withVwap con sessione us: il VWAP riparte dall’apertura, non da mezzanotte', () => {
  const t0 = utc('2026-11-02T14:28:00Z');
  const cs = [0, 1, 2, 3].map((i) => ({ t: t0 + i * 60_000, o: 100 + i * 10, h: 100 + i * 10, l: 100 + i * 10, c: 100 + i * 10, v: 10, bv: 5 }));
  const r = M.withVwap(cs, makeSessionId('us'));
  assert.equal(r[1].vwap, 105);  // 14:28 e 14:29: sessione precedente
  assert.equal(r[2].vwap, 120);  // 14:30: riparte
  assert.equal(r[3].vwap, 125);
});

test('priceDecimals per ordine di grandezza', () => {
  assert.equal(M.priceDecimals(78_000), 1);
  assert.equal(M.priceDecimals(4_500), 2);   // oro
  assert.equal(M.priceDecimals(250), 2);     // azione
  assert.equal(M.priceDecimals(3), 3);
  assert.equal(M.priceDecimals(0.4), 5);
});
