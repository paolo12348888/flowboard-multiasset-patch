// Feed di mercato: WebSocket Binance Futures (con riconnessione + watchdog) oppure generatore demo offline.

export async function loadHistory(cfg, engine) {
  const r = await fetch(`${cfg.rest}/fapi/v1/klines?symbol=${cfg.symbol}&interval=1m&limit=1500`);
  if (r.status === 400) throw new Error(`Simbolo ${cfg.symbol} non trovato su Binance Futures`);
  if (!r.ok) throw new Error(r.status === 451 ? 'Area geo-bloccata da Binance (HTTP 451)' : `Storico non disponibile (HTTP ${r.status})`);
  engine.setHistory(await r.json());
}

function route(engine, d) {
  switch (d.e) {
    case 'aggTrade': engine.onAggTrade(d); break;
    case 'kline': engine.onKline(d.k); break;
    case 'depthUpdate': engine.onDepth(d); break;
    case 'markPriceUpdate': engine.onMark(d); break;
    case 'forceOrder': engine.onForce(d); break;
  }
}

/** onStatus(stato, dettaglio): 'connecting' | 'live' | 'reconnecting' | 'error' */
export function startLive(cfg, engine, onStatus) {
  const sym = cfg.symbol.toLowerCase();
  const streams = [`${sym}@aggTrade`, `${sym}@kline_1m`, `${sym}@depth20@100ms`, `${sym}@markPrice@1s`, `${sym}@forceOrder`].join('/');
  let ws = null, stopped = false, retry = 0, lastMsg = 0, timer = null;

  const schedule = () => {
    if (stopped) return;
    retry += 1;
    onStatus('reconnecting', `tentativo ${retry}`);
    timer = setTimeout(connect, Math.min(15_000, 500 * 2 ** Math.min(retry, 6)));
  };

  async function connect() {
    if (stopped) return;
    onStatus('connecting');
    try { await loadHistory(cfg, engine); }
    catch (e) { onStatus('error', e.message); return schedule(); }
    const me = new WebSocket(`${cfg.ws}?streams=${streams}`);
    ws = me;
    me.onopen = () => { retry = 0; lastMsg = Date.now(); onStatus('live'); };
    me.onmessage = (ev) => { lastMsg = Date.now(); try { const m = JSON.parse(ev.data); route(engine, m.data || m); } catch { /* frame malformato: ignora */ } };
    me.onerror = () => me.close();
    me.onclose = () => { if (ws === me) schedule(); };
  }

  const watchdog = setInterval(() => {
    if (ws && ws.readyState === 1 && Date.now() - lastMsg > 10_000) ws.close(); // feed muto -> riconnetti
  }, 5_000);

  const pollOI = async () => {
    try {
      const r = await fetch(`${cfg.rest}/fapi/v1/openInterest?symbol=${cfg.symbol}`);
      if (r.ok) { const j = await r.json(); engine.onOI(+j.openInterest, j.time || Date.now()); }
    } catch { /* l'OI è opzionale: il punteggio si rinormalizza senza */ }
  };
  const oiTimer = setInterval(pollOI, 10_000);
  pollOI();
  connect();

  return () => { stopped = true; clearTimeout(timer); clearInterval(watchdog); clearInterval(oiTimer); if (ws) ws.close(); };
}

/** Generatore sintetico per provare la UI offline (?demo). Il regime di aggressività deriva lentamente. */
export function startDemo(cfg, engine, onStatus) {
  const rnd = (() => { let s = 42; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); })();
  const gauss = () => Math.sqrt(-2 * Math.log(rnd() + 1e-12)) * Math.cos(2 * Math.PI * rnd());
  let price = 78_000, now = Date.now();
  const start = Math.floor(now / 60_000) * 60_000 - 1499 * 60_000;
  const ks = [];
  for (let i = 0; i < 1500; i++) {
    const o = price; price *= 1 + gauss() * 0.0004;
    const h = Math.max(o, price) * (1 + rnd() * 0.0002), l = Math.min(o, price) * (1 - rnd() * 0.0002);
    const v = 40 + rnd() * 80, bv = v * (0.5 + gauss() * 0.04);
    ks.push([start + i * 60_000, o, h, l, price, v, 0, 0, 0, bv]);
  }
  engine.setHistory(ks);
  engine.last = price;
  let bias = 0.55, oi = 82_000;
  engine.onMark({ p: price, r: 0.0001, T: Date.now() + 3_600_000 });
  onStatus('demo');

  const cur = () => engine.c1m[engine.c1m.length - 1];
  const t1 = setInterval(() => {
    bias += (0.5 - bias) * 0.002 + gauss() * 0.01; bias = Math.min(0.8, Math.max(0.2, bias));
    for (let i = 0; i < 6; i++) {
      const buy = rnd() < bias, q = rnd() < 0.03 ? 2 + rnd() * 6 : rnd() * 0.4;
      price *= 1 + (buy ? 1 : -1) * 0.000004 * (1 + q) + gauss() * 0.000004;
      const T = Date.now();
      engine.onAggTrade({ p: price, q, T, m: !buy });
      const c = cur(), minute = Math.floor(T / 60_000) * 60_000;
      engine.onKline(c && c.t === minute
        ? { t: c.t, o: c.o, h: Math.max(c.h, price), l: Math.min(c.l, price), c: price, v: c.v + q, V: c.bv + (buy ? q : 0) }
        : { t: minute, o: price, h: price, l: price, c: price, v: q, V: buy ? q : 0 });
    }
  }, 50);
  const t2 = setInterval(() => {
    const lean = (bias - 0.5) * 2, mk = (dir) => Array.from({ length: 20 }, (_, i) => [
      (price + dir * (0.5 + i * 0.5)).toFixed(1), ((1 + rnd() * 3) * (1 + dir * lean * 0.6)).toFixed(3)]);
    engine.onDepth({ b: mk(-1), a: mk(1) });
    engine.onMark({ p: price, r: 0.0001, T: Date.now() + 3_600_000 });
    if (rnd() < 0.05) engine.onForce({ o: { T: Date.now(), S: rnd() < 0.5 ? 'SELL' : 'BUY', ap: price, q: 0.5 + rnd() * 4 } });
  }, 250);
  const t3 = setInterval(() => { oi += (bias - 0.5) * 40 + gauss() * 8; engine.onOI(oi); }, 2_000);
  engine.onOI(oi);
  return () => { clearInterval(t1); clearInterval(t2); clearInterval(t3); };
}
