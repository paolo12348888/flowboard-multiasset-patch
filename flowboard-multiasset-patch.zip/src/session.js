// Identificatore di sessione per ancorare il VWAP.
//  'utc'   -> un giorno UTC (default, giusto per crypto 24/7)
//  'us'    -> apertura cash USA, 09:30 New York (gestisce l'ora legale: 13:30 UTC d'estate, 14:30 d'inverno)
//  'HH:MM' -> ora UTC personalizzata (es. '07:00' per l'apertura di Francoforte in inverno)
const DAY = 86_400_000, H = 3_600_000;

const nyFmt = new Intl.DateTimeFormat('en-US', { timeZone: 'America/New_York', timeZoneName: 'longOffset' });
const cache = new Map();

/** Offset di New York rispetto a UTC, in ms (negativo). Memorizzato per ora. */
function nyOffset(t) {
  const k = Math.floor(t / H);
  let v = cache.get(k);
  if (v === undefined) {
    const name = nyFmt.formatToParts(new Date(t)).find((p) => p.type === 'timeZoneName')?.value || '';
    const m = /GMT([+-])(\d{2}):(\d{2})/.exec(name);
    v = m ? (m[1] === '-' ? -1 : 1) * (+m[2] * H + +m[3] * 60_000) : 0;
    if (cache.size > 5000) cache.clear();
    cache.set(k, v);
  }
  return v;
}

export function makeSessionId(spec = 'utc') {
  if (spec === 'us') return (t) => Math.floor((t + nyOffset(t) - 9.5 * H) / DAY);
  const m = /^(\d{1,2}):(\d{2})$/.exec(spec);
  if (m) { const off = +m[1] * H + +m[2] * 60_000; return (t) => Math.floor((t - off) / DAY); }
  return (t) => Math.floor(t / DAY);
}
