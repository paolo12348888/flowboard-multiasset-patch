// Stato di mercato + calcolo del punteggio. Nessun accesso a rete o DOM: alimentabile da qualsiasi feed.
import * as M from './metrics.js';
import { makeSessionId } from './session.js';

const MAX_1M = 1600;      // ~26 ore di candele 1m
const BIN_KEEP_S = 900;   // 15 minuti di bin al secondo

export class Engine {
  constructor(cfg) {
    this.cfg = cfg;
    this.sessionId = makeSessionId(cfg.session);
    this.c1m = [];
    this.bins = [];
    this.book = { bids: [], asks: [] };
    this.obi = null;
    this.oiHist = [];
    this.mark = null;
    this.funding = null;
    this.nextFunding = null;
    this.liqs = [];
    this.last = null;
    this.smooth = null;
    this.regime = 'flat';
  }

  /** klines REST: [openTime, o, h, l, c, vol, closeTime, quoteVol, trades, takerBuyBase, ...] */
  setHistory(klines) {
    this.c1m = klines.map((k) => ({ t: k[0], o: +k[1], h: +k[2], l: +k[3], c: +k[4], v: +k[5], bv: +k[9] }));
  }

  /** evento stream kline_1m: k.V = volume taker-buy base */
  onKline(k) {
    const c = { t: k.t, o: +k.o, h: +k.h, l: +k.l, c: +k.c, v: +k.v, bv: +k.V };
    const last = this.c1m[this.c1m.length - 1];
    if (last && last.t === c.t) this.c1m[this.c1m.length - 1] = c;
    else if (!last || c.t > last.t) {
      this.c1m.push(c);
      if (this.c1m.length > MAX_1M) this.c1m.shift();
    }
  }

  /** evento aggTrade: m = true -> il buyer è maker -> aggressore VENDITORE */
  onAggTrade(d) {
    const p = +d.p, q = +d.q, sec = Math.floor(d.T / 1000);
    this.last = p;
    let b = this.bins[this.bins.length - 1];
    if (!b || sec > b.s) {
      b = { s: sec, buy: 0, sell: 0, lbuy: 0, lsell: 0 };
      this.bins.push(b);
      while (this.bins.length && this.bins[0].s < sec - BIN_KEEP_S) this.bins.shift();
    }
    const large = p * q >= this.cfg.largeLotUsd;
    if (d.m) { b.sell += q; if (large) b.lsell += q; }
    else { b.buy += q; if (large) b.lbuy += q; }
  }

  /** evento depth (partial book): b/a = [[prezzo, qty], ...] come stringhe */
  onDepth(d) {
    const parse = (a) => (a || []).map(([p, q]) => [+p, +q]);
    this.book = { bids: parse(d.b ?? d.bids), asks: parse(d.a ?? d.asks) };
    const raw = M.bookImbalance(this.book.bids, this.book.asks, this.cfg.book.decayBps, this.cfg.book.levels);
    if (raw != null) this.obi = M.ema(this.obi, raw, this.cfg.book.emaAlpha);
  }

  onMark(d) {
    this.mark = +d.p;
    this.funding = +d.r;
    this.nextFunding = d.T;
  }

  /** forceOrder: S = 'SELL' significa che una posizione LONG è stata liquidata */
  onForce(d) {
    const o = d.o || d;
    this.liqs.push({ t: o.T, longLiq: o.S === 'SELL', usd: +o.ap * +o.q });
    const cut = Date.now() - 15 * 60_000;
    while (this.liqs.length && this.liqs[0].t < cut) this.liqs.shift();
  }

  onOI(v, t = Date.now()) {
    this.oiHist.push({ t, v });
    const cut = t - 40 * 60_000;
    while (this.oiHist.length && this.oiHist[0].t < cut) this.oiHist.shift();
  }

  _oi() {
    const h = this.oiHist;
    if (!h.length) return null;
    const cur = h[h.length - 1];
    let pct = null;
    const target = cur.t - this.cfg.oiWindowMin * 60_000;
    for (let i = h.length - 1; i >= 0; i--) {
      if (h[i].t <= target) {
        if (cur.t - h[i].t <= (this.cfg.oiWindowMin + 3) * 60_000) pct = (cur.v / h[i].v - 1) * 100;
        break;
      }
    }
    return { value: cur.v, pct };
  }

  /** Istantanea grezza (senza smoothing). */
  snapshot(tf, now = Date.now()) {
    if (!this.c1m.length) return null;
    const c1 = M.withVwap(this.c1m, this.sessionId);
    const lastC = c1[c1.length - 1];
    const price = this.last ?? lastC.c;
    const candles = M.aggregate(c1, tf);

    const sid = this.sessionId(lastC.t);
    const dayOpen = (c1.find((c) => this.sessionId(c.t) === sid) || c1[0]).o;
    const dayPct = (price / dayOpen - 1) * 100;

    const { windowsMin, blend } = this.cfg.flow;
    const flows = windowsMin.map((m) => M.flowFromBins(this.bins, now, m * 60_000));
    const flowX = flows.reduce((s, f, i) => s + f.x * blend[i], 0);
    const f5 = flows[Math.max(0, windowsMin.indexOf(5))];
    const lotTot = f5.lbuy + f5.lsell;
    const lotConf = Math.min(1, (lotTot * price) / (5 * this.cfg.largeLotUsd));

    const cvd = M.cvdSignal(c1, this.cfg.cvdWindowMin);
    const sd = Math.max(lastC.sd, price * 0.0002);
    const z = M.vwapZ(price, lastC.vwap, lastC.sd);

    const oi = this._oi();
    const ago = c1[c1.length - 1 - this.cfg.oiWindowMin];
    const dP = ago ? (price / ago.c - 1) * 100 : null;
    const oiSig = oi && oi.pct != null && dP != null ? M.oiPriceSignal(oi.pct, dP) : null;

    const parts = {
      flow: M.squash(flowX, 0.15),
      large: M.squash(f5.lx, 0.4) * lotConf,
      cvd: M.squash(cvd.x, 0.10),
      obi: this.obi == null ? null : M.squash(this.obi, 0.25),
      vwap: M.squash(z, 1.5),
      oi: oiSig,
    };
    const score = M.composite(parts, this.cfg.weights);

    const { bids, asks } = this.book;
    const spreadBps = bids.length && asks.length ? ((asks[0][0] - bids[0][0]) / price) * 1e4 : null;
    const liq5 = this.liqs.filter((l) => l.t >= now - 5 * 60_000);

    return {
      now, price, dayPct, candles, sessionId: this.sessionId, vwap: lastC.vwap, sd, z,
      parts, score,
      raw: { flowX, flows, f5, cvd, obi: this.obi, oi, dP, lotTot },
      funding: this.funding, nextFunding: this.nextFunding, spreadBps,
      vol: M.realizedVol(c1, 60),
      liq: {
        long: liq5.filter((l) => l.longLiq).reduce((s, l) => s + l.usd, 0),
        short: liq5.filter((l) => !l.longLiq).reduce((s, l) => s + l.usd, 0),
      },
    };
  }

  /** Istantanea + smoothing EMA + verdetto con isteresi. Da chiamare a cadenza fissa. */
  tick(tf, now = Date.now()) {
    const s = this.snapshot(tf, now);
    if (!s) return null;
    this.smooth = M.ema(this.smooth, s.score, this.cfg.smoothing);
    this.regime = M.regime(this.regime, this.smooth, this.cfg.regime.enter, this.cfg.regime.exit);
    s.score = this.smooth;
    s.regime = this.regime;
    s.buyersPct = M.toBuyersPct(this.smooth);
    return s;
  }
}
