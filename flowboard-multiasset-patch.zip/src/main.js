import { CONFIG } from './config.js';
import { Engine } from './engine.js';
import { startLive, startDemo } from './feed.js';
import { Chart } from './chart.js';
import * as M from './metrics.js';

const q = new URLSearchParams(location.search);
const cfg = {
  ...CONFIG,
  symbol: (q.get('symbol') || CONFIG.symbol).toUpperCase(),
  session: q.get('session') || CONFIG.session,
  largeLotUsd: Number(q.get('lot')) || CONFIG.largeLotUsd,
};
let tf = Number(q.get('tf')) || cfg.defaultTf;
const demo = q.has('demo');
const $ = (id) => document.getElementById(id);

const nf = (d) => new Intl.NumberFormat('it-IT', { minimumFractionDigits: d, maximumFractionDigits: d });
const f1 = nf(1), f2 = nf(2), f3 = nf(3), f4 = nf(4);
let dec = 1, P = f1; // formattatore prezzi: i decimali dipendono dall'asset
// it-IT non compatta le migliaia: formattazione propria (k / M)
const compact = { format: (n) => (Math.abs(n) >= 1e6 ? f1.format(n / 1e6) + ' M' : Math.abs(n) >= 1e3 ? f1.format(n / 1e3) + ' k' : f1.format(n)) };
const sgn = (x, f = f2) => (x > 0 ? '+' : '') + f.format(x);
const base = cfg.symbol.replace(/(USDT|USDC|BUSD)$/, '');

// ---------- DOM statico ----------
$('sym').textContent = base;
$('sub').textContent = `Perpetual ${cfg.symbol} \u00b7 ${demo ? 'dati sintetici di prova' : 'dati Binance Futures'}`;
document.title = `${base} flow \u00b7 Flowboard`;
const tfSel = $('tf');
for (const m of cfg.timeframes) tfSel.add(new Option(m >= 60 ? `${m / 60}h` : `${m}m`, m, false, m === tf));
if (![...tfSel.options].some((o) => +o.value === tf)) tfSel.add(new Option(`${tf}m`, tf, true, true));
tfSel.addEventListener('change', () => { tf = +tfSel.value; tick(); });

const ROWS = [
  { id: 'flow', k: 'Flusso taker', sub: 'acquisti vs vendite a mercato, 1/5/15 min' },
  { id: 'large', k: 'Lotti grandi', sub: `ordini singoli da ${compact.format(cfg.largeLotUsd)} $ in su, 5 min` },
  { id: 'cvd', k: `Delta cumulato ${cfg.cvdWindowMin}m`, sub: 'volume netto aggressivo' },
  { id: 'obi', k: 'Order book', sub: 'sbilanciamento bid/ask pesato per distanza' },
  { id: 'vwap', k: 'Prezzo vs VWAP', sub: 'distanza in deviazioni standard' },
  { id: 'oi', k: 'Open interest', sub: 'posizioni aperte vs direzione del prezzo, 5 min' },
];
const rowEl = {};
for (const r of ROWS) {
  const li = document.createElement('li'); li.className = 'row';
  li.innerHTML = `<div class="k">${r.k}<small>${r.sub}</small></div><div class="v">\u2013</div><div class="meter"><i></i></div>`;
  $('rows').append(li);
  rowEl[r.id] = { v: li.querySelector('.v'), i: li.querySelector('.meter i'), k: li.querySelector('.k') };
}
const STATS = ['funding', 'oi', 'spread', 'vol', 'liq', 'sigma'];
const statEl = {};
const statLabels = { funding: 'Funding', oi: 'Open interest', spread: 'Spread', vol: 'Volatilità 1h (ann.)', liq: 'Liquidazioni 5m', sigma: 'Distanza dal VWAP' };
for (const id of STATS) {
  const d = document.createElement('div'); d.className = 'stat';
  d.innerHTML = `<span>${statLabels[id]}</span><b>\u2013</b> <small></small>`;
  $('stats').append(d); statEl[id] = { b: d.querySelector('b'), s: d.querySelector('small') };
}

// ---------- logica ----------
const engine = new Engine(cfg);
const chart = new Chart($('chart'), {
  onHover: (c) => {
    $('ohlc').textContent = c
      ? `${new Date(c.t).toLocaleString('it-IT', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' })}  O ${P.format(c.o)}  H ${P.format(c.h)}  L ${P.format(c.l)}  C ${P.format(c.c)}  \u0394 ${sgn(2 * c.bv - c.v, f1)}`
      : '';
  },
});

const STATUS = {
  connecting: ['connessione\u2026', ''], live: ['in diretta', 'live'], demo: ['demo', 'demo'],
  reconnecting: ['riconnessione\u2026', 'err'], error: ['errore', 'err'],
};
let lastErr = '';
const onStatus = (s, detail) => {
  const [txt, cls] = STATUS[s] || [s, ''];
  const el = $('status'); el.textContent = txt; el.className = `status ${cls}`;
  lastErr = s === 'error' ? detail || '' : (s === 'live' ? '' : lastErr);
  $('note').textContent = lastErr;
};

const VERDICT = {
  buy: ['I compratori stanno vincendo', 'Compratori in vantaggio'],
  sell: ['I venditori stanno vincendo', 'Venditori in vantaggio'],
  flat: ['Mercato in equilibrio', 'Equilibrio'],
};

function meter(el, score) {
  const s = Math.max(-1, Math.min(1, score ?? 0)), w = Math.abs(s) * 50;
  el.i.className = s >= 0 ? 'pos' : 'neg';
  el.i.style.left = (s >= 0 ? 50 : 50 - w) + '%'; el.i.style.width = w + '%';
}

function render(s) {
  const nd = M.priceDecimals(s.price);
  if (nd !== dec) { dec = nd; P = nf(nd); }
  $('price').textContent = P.format(s.price);
  const d = $('dayPct'); d.textContent = `${sgn(s.dayPct)} % ${cfg.session === 'utc' ? 'oggi (UTC)' : 'da apertura sessione'}`; d.className = 'day ' + (s.dayPct >= 0 ? 'up' : 'dn');

  const b = Math.round(s.buyersPct), v = 100 - b;
  for (const id of ['bPctMini', 'bPct']) $(id).textContent = b + '%';
  for (const id of ['sPctMini', 'sPct']) $(id).textContent = v + '%';
  for (const id of ['barBuy', 'barBuy2']) $(id).style.width = s.buyersPct + '%';
  for (const id of ['barSell', 'barSell2']) $(id).style.width = 100 - s.buyersPct + '%';
  const h = $('headline'); h.textContent = VERDICT[s.regime][0]; h.className = 'headline ' + s.regime;
  const vd = $('verdict'); vd.textContent = VERDICT[s.regime][1]; vd.className = 'verdict ' + s.regime;

  const r = s.raw, p = s.parts;
  const set = (id, txt, sc) => { rowEl[id].v.textContent = txt; meter(rowEl[id], sc); };
  set('flow', `${sgn(r.flowX * 100, f1)}%`, p.flow);
  set('large', r.lotTot > 0 ? `\u0394 ${sgn(r.f5.lbuy - r.f5.lsell, f1)} ${base}` : 'nessun lotto', p.large);
  set('cvd', `\u0394 ${sgn(r.cvd.delta, f1)} ${base}`, p.cvd);
  rowEl.cvd.k.querySelector('.tag')?.remove();
  if (r.cvd.divergence) {
    const t = document.createElement('span'); t.className = 'tag';
    t.textContent = r.cvd.divergence === 'bear' ? 'rialzo debole' : 'ribasso debole';
    rowEl.cvd.k.firstChild.after(t);
  }
  set('obi', r.obi == null ? 'n/d' : sgn(r.obi, f2), p.obi);
  set('vwap', `${sgn(s.z, f1)} \u03c3`, p.vwap);
  set('oi', r.oi && r.oi.pct != null ? `${sgn(r.oi.pct, f3)}% \u00b7 ${M.oiLabel(r.oi.pct, r.dP)}` : r.oi ? 'in raccolta\u2026' : 'n/d', p.oi);

  statEl.funding.b.textContent = s.funding == null ? '\u2013' : `${sgn(s.funding * 100, f4)}%`;
  if (s.nextFunding) { const m = Math.max(0, Math.round((s.nextFunding - s.now) / 60_000)); statEl.funding.s.textContent = `tra ${Math.floor(m / 60)}h ${m % 60}m`; }
  statEl.oi.b.textContent = r.oi ? compact.format(r.oi.value) : '\u2013'; statEl.oi.s.textContent = base;
  statEl.spread.b.textContent = s.spreadBps == null ? '\u2013' : f2.format(s.spreadBps); statEl.spread.s.textContent = 'bps';
  statEl.vol.b.textContent = s.vol == null ? '\u2013' : f1.format(s.vol) + '%';
  statEl.liq.b.textContent = `${compact.format(s.liq.long)} / ${compact.format(s.liq.short)}`; statEl.liq.s.textContent = 'long / short $';
  statEl.sigma.b.textContent = `${sgn(s.z, f1)} \u03c3`; statEl.sigma.s.textContent = `VWAP ${P.format(s.vwap)}`;

  chart.setData({ candles: s.candles, price: s.price, now: s.now, sessionId: s.sessionId, dec });
}

function tick() { const s = engine.tick(tf); if (s) render(s); }
setInterval(tick, cfg.tickMs);
(function loop() { chart.draw(); requestAnimationFrame(loop); })();

if (demo) startDemo(cfg, engine, onStatus);
else startLive(cfg, engine, onStatus);
