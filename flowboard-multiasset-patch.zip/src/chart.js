// Grafico a candele su <canvas>: candele + VWAP con banda ±1σ + pannello delta. Zero dipendenze.
const C = {
  grid: 'rgba(120,170,180,0.10)', axis: '#6f8c93', up: '#3b9bff', down: '#ff6a2b',
  vwap: '#ffb020', band: 'rgba(255,176,32,0.09)', last: '#e9f3f4', lastTxt: '#06161c',
  recent: 'rgba(255,61,113,0.07)', recentTag: '#ff3d71', cross: 'rgba(233,243,244,0.35)',
};

const niceStep = (range, target) => {
  const raw = range / target, p = 10 ** Math.floor(Math.log10(raw)), n = raw / p;
  return (n < 1.5 ? 1 : n < 3.5 ? 2 : n < 7.5 ? 5 : 10) * p;
};
const fmtP = (p, d, fixed = false) => p.toLocaleString('it-IT', { minimumFractionDigits: fixed ? d : 0, maximumFractionDigits: d });
const fmtT = (t) => new Date(t).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' });

export class Chart {
  constructor(canvas, { visible = 64, onHover = () => {} } = {}) {
    this.cv = canvas; this.ctx = canvas.getContext('2d');
    this.visible = visible; this.onHover = onHover;
    this.data = null; this.hoverIdx = null; this.dirty = true;
    new ResizeObserver(() => { this.dirty = true; this.draw(); }).observe(canvas);
    const move = (e) => {
      if (!this.geo) return;
      const r = canvas.getBoundingClientRect(), x = e.clientX - r.left;
      const i = Math.round((x - this.geo.x0) / this.geo.step);
      this.hoverIdx = i >= 0 && i < this.geo.n ? i : null;
      this.onHover(this.hoverIdx == null ? null : this.geo.slice[this.hoverIdx]);
      this.dirty = true; this.draw();
    };
    const leave = () => { this.hoverIdx = null; this.onHover(null); this.dirty = true; this.draw(); };
    canvas.addEventListener('pointermove', move);
    canvas.addEventListener('pointerdown', move);
    canvas.addEventListener('pointerleave', leave);
  }

  setData(d) { this.data = d; this.dirty = true; }

  draw() {
    if (!this.dirty || !this.data) return;
    this.dirty = false;
    const cv = this.cv, dpr = window.devicePixelRatio || 1;
    const W = cv.clientWidth, H = cv.clientHeight;
    if (!W || !H) return;
    if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) { cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); }
    const g = this.ctx; g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, W, H);

    const slice = this.data.candles.slice(-this.visible), n = slice.length, dec = this.data.dec ?? 1;
    if (n < 2) return;
    const padR = 58, padT = 8, padB = 18, gap = 8;
    const deltaH = Math.round((H - padT - padB) * 0.18);
    const priceB = H - padB - deltaH - gap, priceH = priceB - padT;
    const slots = n + 3, step = (W - padR - 4) / slots, bw = Math.max(1, Math.min(10, step * 0.62)), x0 = step * 0.5 + 2;
    const xAt = (i) => x0 + i * step;

    let lo = Infinity, hi = -Infinity;
    for (const c of slice) { lo = Math.min(lo, c.l, c.vwap); hi = Math.max(hi, c.h, c.vwap); }
    const pad = (hi - lo) * 0.08 || 1; lo -= pad; hi += pad;
    const y = (p) => padT + (1 - (p - lo) / (hi - lo)) * priceH;
    this.geo = { x0, step, n, slice };

    // griglia + asse prezzi
    g.font = '10px "IBM Plex Mono", ui-monospace, monospace'; g.textBaseline = 'middle'; g.textAlign = 'left';
    const st = niceStep(hi - lo, 5);
    for (let p = Math.ceil(lo / st) * st; p < hi; p += st) {
      g.strokeStyle = C.grid; g.beginPath(); g.moveTo(0, y(p)); g.lineTo(W - padR, y(p)); g.stroke();
      g.fillStyle = C.axis; g.fillText(fmtP(p, dec), W - padR + 6, y(p));
    }

    // ultima mezz'ora
    const now = this.data.now, recentIdx = slice.findIndex((c) => c.t >= now - 30 * 60_000);
    if (recentIdx >= 0 && recentIdx < n - 1) {
      const xr = xAt(recentIdx) - step / 2;
      g.fillStyle = C.recent; g.fillRect(xr, padT, W - padR - xr, priceH);
      g.font = '600 9px "IBM Plex Mono", ui-monospace, monospace';
      const label = 'ultima mezz\u2019ora', tw = g.measureText(label).width + 10;
      const lx = Math.max(0, Math.min(xr, W - padR - tw));
      g.fillStyle = C.recentTag; g.fillRect(lx, priceB - 14, tw, 13);
      g.fillStyle = '#fff'; g.textAlign = 'left'; g.fillText(label, lx + 5, priceB - 7.5);
    }

    // banda VWAP ±1σ + linea VWAP
    g.save(); g.beginPath(); g.rect(0, padT, W - padR, priceH); g.clip();
    const sid = this.data.sessionId || ((t) => Math.floor(t / 86_400_000)), dayOf = (c) => sid(c.t), segs = [];
    slice.forEach((c, i) => { if (!i || dayOf(c) !== dayOf(slice[i - 1])) segs.push([i, i]); else segs[segs.length - 1][1] = i; });
    for (const [a, b] of segs) {
      g.beginPath();
      for (let i = a; i <= b; i++) (i === a ? g.moveTo : g.lineTo).call(g, xAt(i), y(slice[i].vwap + slice[i].sd));
      for (let i = b; i >= a; i--) g.lineTo(xAt(i), y(slice[i].vwap - slice[i].sd));
      g.closePath(); g.fillStyle = C.band; g.fill();
      g.beginPath();
      for (let i = a; i <= b; i++) (i === a ? g.moveTo : g.lineTo).call(g, xAt(i), y(slice[i].vwap));
      g.strokeStyle = C.vwap; g.lineWidth = 1.4; g.stroke(); g.lineWidth = 1;
    }

    // candele
    slice.forEach((c, i) => {
      const x = xAt(i), up = c.c >= c.o; g.strokeStyle = g.fillStyle = up ? C.up : C.down;
      g.beginPath(); g.moveTo(x, y(c.h)); g.lineTo(x, y(c.l)); g.stroke();
      const top = y(Math.max(c.o, c.c)), h = Math.max(1, Math.abs(y(c.o) - y(c.c)));
      g.fillRect(x - bw / 2, top, bw, h);
    });
    g.restore();

    // prezzo corrente + tag VWAP
    const lastC = slice[n - 1], price = this.data.price;
    const tag = (p, txt, bg, fg) => {
      const yy = Math.min(priceB - 7, Math.max(padT + 7, y(p)));
      g.fillStyle = bg; g.fillRect(W - padR + 2, yy - 8, padR - 3, 16);
      g.fillStyle = fg; g.font = '600 10px "IBM Plex Mono", ui-monospace, monospace'; g.textAlign = 'left'; g.fillText(txt, W - padR + 5, yy);
    };
    g.setLineDash([2, 3]); g.strokeStyle = 'rgba(233,243,244,0.55)'; g.beginPath(); g.moveTo(0, y(price)); g.lineTo(W - padR, y(price)); g.stroke(); g.setLineDash([]);
    tag(lastC.vwap, fmtP(lastC.vwap, dec, true), C.vwap, '#2a1c00');
    tag(price, fmtP(price, dec, true), C.last, C.lastTxt);

    // pannello delta
    const dTop = priceB + gap, dMid = dTop + deltaH / 2;
    const deltas = slice.map((c) => 2 * c.bv - c.v), dMax = Math.max(1e-9, ...deltas.map(Math.abs));
    g.strokeStyle = C.grid; g.beginPath(); g.moveTo(0, dMid); g.lineTo(W - padR, dMid); g.stroke();
    deltas.forEach((d, i) => {
      const h = (Math.abs(d) / dMax) * (deltaH / 2 - 1); g.fillStyle = d >= 0 ? C.up : C.down;
      g.globalAlpha = 0.85; g.fillRect(xAt(i) - bw / 2, d >= 0 ? dMid - h : dMid, bw, Math.max(1, h)); g.globalAlpha = 1;
    });
    g.fillStyle = C.axis; g.font = '10px "IBM Plex Mono", ui-monospace, monospace'; g.textAlign = 'left';
    g.fillText('\u0394 volume', W - padR + 6, dMid);

    // asse tempi
    g.textAlign = 'center'; const every = Math.max(1, Math.round(60 / step));
    for (let i = n - 1; i >= 0; i -= every) { g.fillStyle = C.axis; g.fillText(fmtT(slice[i].t), xAt(i), H - 7); }

    // mirino
    if (this.hoverIdx != null && this.hoverIdx < n) {
      const x = xAt(this.hoverIdx); g.strokeStyle = C.cross; g.beginPath(); g.moveTo(x, padT); g.lineTo(x, H - padB); g.stroke();
    }
  }
}
