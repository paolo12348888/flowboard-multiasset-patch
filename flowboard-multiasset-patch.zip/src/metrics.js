// Funzioni PURE (nessun I/O, nessun DOM): testabili e riusabili.
// Convenzioni: candela 1m = { t, o, h, l, c, v, bv }  dove v = volume base, bv = volume taker-buy.
// Volume taker-sell = v - bv.  Delta = bv - (v - bv) = 2*bv - v.

const MIN = 60_000;
const DAY = 86_400_000;

export const clamp = (x, lo, hi) => Math.min(hi, Math.max(lo, x));
/** Comprime un valore illimitato in (-1, 1). `scale` = valore che vale ~0.76. */
export const squash = (x, scale) => Math.tanh(x / scale);
export const ema = (prev, x, a) => (prev == null ? x : prev + a * (x - prev));

/** VWAP di sessione (default: ancorata a 00:00 UTC; vedi session.js per altre sessioni) con deviazione standard pesata per volume. */
export function withVwap(c1m, sessionId = (t) => Math.floor(t / DAY)) {
  let day = null, pv = 0, v = 0, p2v = 0;
  return c1m.map((c) => {
    const d = sessionId(c.t);
    if (d !== day) { day = d; pv = 0; v = 0; p2v = 0; }
    const tp = (c.h + c.l + c.c) / 3;
    pv += tp * c.v; v += c.v; p2v += tp * tp * c.v;
    const vwap = v > 0 ? pv / v : tp;
    const sd = v > 0 ? Math.sqrt(Math.max(0, p2v / v - vwap * vwap)) : 0;
    return { ...c, vwap, sd };
  });
}

/** Aggrega candele 1m in candele da n minuti allineate all'epoch. Porta con sé vwap/sd dell'ultima 1m. */
export function aggregate(c1m, n) {
  if (n <= 1) return c1m.slice();
  const span = n * MIN, out = [];
  let cur = null;
  for (const c of c1m) {
    const b = Math.floor(c.t / span) * span;
    if (!cur || cur.t !== b) {
      cur = { t: b, o: c.o, h: c.h, l: c.l, c: c.c, v: c.v, bv: c.bv, vwap: c.vwap, sd: c.sd };
      out.push(cur);
    } else {
      cur.h = Math.max(cur.h, c.h); cur.l = Math.min(cur.l, c.l); cur.c = c.c;
      cur.v += c.v; cur.bv += c.bv; cur.vwap = c.vwap; cur.sd = c.sd;
    }
  }
  return out;
}

/**
 * Flusso taker da bin al secondo: { s, buy, sell, lbuy, lsell }.
 * x = (buy - sell) / (buy + sell) in [-1, 1]; lx idem per i soli lotti grandi.
 */
export function flowFromBins(bins, nowMs, windowMs) {
  const from = nowMs - windowMs;
  let buy = 0, sell = 0, lbuy = 0, lsell = 0;
  for (let i = bins.length - 1; i >= 0; i--) {
    const b = bins[i];
    if (b.s * 1000 < from) break;
    buy += b.buy; sell += b.sell; lbuy += b.lbuy; lsell += b.lsell;
  }
  const tot = buy + sell, ltot = lbuy + lsell;
  return { buy, sell, lbuy, lsell, x: tot > 0 ? (buy - sell) / tot : 0, lx: ltot > 0 ? (lbuy - lsell) / ltot : 0 };
}

/** Delta cumulato (CVD) sulle ultime n candele 1m + rilevamento divergenza prezzo/delta. */
export function cvdSignal(c1m, n) {
  const w = c1m.slice(-n);
  let d = 0, v = 0;
  for (const c of w) { d += 2 * c.bv - c.v; v += c.v; }
  const x = v > 0 ? d / v : 0;
  const pc = w.length > 1 ? w[w.length - 1].c / w[0].o - 1 : 0;
  let divergence = null;
  if (Math.abs(x) > 0.03 && Math.abs(pc) > 0.0003 && Math.sign(x) !== Math.sign(pc)) {
    divergence = pc > 0 ? 'bear' : 'bull'; // prezzo sale con delta negativo = rialzo debole; viceversa
  }
  return { x, delta: d, priceChange: pc, divergence };
}

/** Sbilanciamento order book pesato per distanza dal mid. Ritorna [-1, 1] o null. bids/asks: [[prezzo, qty], ...] */
export function bookImbalance(bids, asks, decayBps = 8, levels = 20) {
  if (!bids.length || !asks.length) return null;
  const mid = (bids[0][0] + asks[0][0]) / 2;
  const side = (arr) => {
    let s = 0;
    for (const [p, q] of arr.slice(0, levels)) s += q * Math.exp(-(Math.abs(mid - p) / mid) * 1e4 / decayBps);
    return s;
  };
  const B = side(bids), A = side(asks);
  return B + A > 0 ? (B - A) / (B + A) : 0;
}

/** Distanza dal VWAP in deviazioni standard (con pavimento per evitare divisioni per ~0). */
export function vwapZ(price, vwap, sd) {
  const floor = price * 0.0002;
  return (price - vwap) / Math.max(sd, floor);
}

/**
 * Open interest vs prezzo. Percentuali in punti (0.05 = 0.05%).
 * Prezzo su + OI su = nuovi long (forte). Prezzo giù + OI su = nuovi short (forte, ribassista).
 * OI giù = chiusure (short covering / liquidazione long): segnale più debole (x0.4).
 */
export function oiPriceSignal(dOiPct, dPricePct) {
  if (!Number.isFinite(dOiPct) || !Number.isFinite(dPricePct)) return null;
  if (Math.abs(dPricePct) < 0.01) return 0;
  const conviction = dOiPct > 0 ? 1 : 0.4;
  return Math.sign(dPricePct) * conviction * Math.tanh(Math.abs(dOiPct) / 0.05);
}

export function oiLabel(dOiPct, dPricePct) {
  if (!Number.isFinite(dOiPct) || !Number.isFinite(dPricePct) || Math.abs(dPricePct) < 0.01) return 'neutro';
  const up = dPricePct > 0;
  if (dOiPct > 0) return up ? 'nuovi long' : 'nuovi short';
  return up ? 'short covering' : 'long liquidati';
}

/** Media pesata delle componenti disponibili, rinormalizzata sui pesi presenti. Ritorna [-1, 1]. */
export function composite(parts, weights) {
  let sw = 0, s = 0;
  for (const k of Object.keys(weights)) {
    const v = parts[k];
    if (v == null || !Number.isFinite(v)) continue;
    s += weights[k] * v; sw += weights[k];
  }
  return sw > 0 ? s / sw : 0;
}

export const toBuyersPct = (score) => 50 + 50 * clamp(score, -1, 1);

/** Verdetto con isteresi: per cambiare stato serve superare `enter`, per uscirne scendere sotto `exit`. */
export function regime(prev, score, enter = 0.15, exit = 0.05) {
  if (prev === 'buy') return score > exit ? 'buy' : score < -enter ? 'sell' : 'flat';
  if (prev === 'sell') return score < -exit ? 'sell' : score > enter ? 'buy' : 'flat';
  return score > enter ? 'buy' : score < -enter ? 'sell' : 'flat';
}

/** Volatilità realizzata annualizzata (%) dai close 1m delle ultime n candele. */
export function realizedVol(c1m, n = 60) {
  const w = c1m.slice(-(n + 1));
  if (w.length < 3) return null;
  const r = [];
  for (let i = 1; i < w.length; i++) r.push(Math.log(w[i].c / w[i - 1].c));
  const m = r.reduce((a, b) => a + b, 0) / r.length;
  const sd = Math.sqrt(r.reduce((a, b) => a + (b - m) ** 2, 0) / (r.length - 1));
  return sd * Math.sqrt(525_600) * 100;
}

/** Decimali di visualizzazione in base all'ordine di grandezza del prezzo (BTC -> 1, oro -> 2, azioni -> 2, penny -> 5). */
export function priceDecimals(price) {
  return price >= 50_000 ? 1 : price >= 100 ? 2 : price >= 1 ? 3 : 5;
}
